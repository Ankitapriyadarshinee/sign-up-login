from django.shortcuts import  render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login as login_required
# Create your views here.
def register(request):

    if request.POST:
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST['password2']

        # Check if passwords match
        if password != password2:
            return render(request, 'register.html', {'error': 'Passwords do not match'})
        # Check if username or email is already taken
        if User.objects.filter(username=username).exists() or User.objects.filter(email=email).exists():
            return render(request, 'register.html', {'error': 'Username or email is already taken'})
        user_obj = User.objects.create(username=username, email=email)
        user_obj.set_password(password)
        user_obj.save()
        return redirect('login')
    return render(request, 'register.html')

def login(request):
    if request.POST:
        email = request.POST.get('email')
        password = request.POST.get('password')
        check_user = User.objects.filter(email=email).first()

        if check_user:
            username = check_user.username
            user_obj = authenticate(username=username, password=password)
            if user_obj is not None:
                login_required(request, user_obj)
                return redirect('dashboard')
        else:
            return render(request, 'login.html', {'error': 'User not found, Please login again'})
    return render(request, 'login.html')



def dashboard(request):
    return render(request,'dashboard.html')


